export function parseTL(s?: string): number {
  if (!s) return 0;
  const norm = s.replace(/\./g, '').replace(',', '.').replace(/\s/g, '');
  const n = Number(norm || 0);
  return isNaN(n) ? 0 : n;
}
