import { Router } from 'express';
import multer from 'multer';
import { PrismaClient } from '@prisma/client';
import { importExcel } from '../importer/importExcel';

const prisma = new PrismaClient();
const upload = multer({ dest: 'uploads/' });

const router = Router();

router.post('/excel', upload.single('file'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'file is required' });

  const staging = await prisma.stagingFile.create({
    data: { originalFilename: req.file.originalname, status: 'PENDING' }
  });

  try {
    const report = await importExcel(staging.id, req.file.path);
    const file = await prisma.stagingFile.findUnique({
      where: { id: staging.id },
      include: { customerBalances: { include: { customer: true } } }
    });
    res.status(201).json({ file, report });
  } catch (e: any) {
    await prisma.stagingFile.update({
      where: { id: staging.id },
      data: { status: 'FAILED', error: e.message }
    });
    res.status(500).json({ error: e.message });
  }
});

router.get('/:id', async (req, res) => {
  const id = Number(req.params.id);
  const file = await prisma.stagingFile.findUnique({
    where: { id },
    include: { customerBalances: { include: { customer: true } } }
  });
  if (!file) return res.status(404).send();
  res.json(file);
});

export default router;
