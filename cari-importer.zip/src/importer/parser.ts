import ExcelJS from 'exceljs';
import { parseDate } from '../utils/date';
import { parseTL } from '../utils/number';

export function rowContains(row: ExcelJS.Row, text: string) {
  return (row.values || []).some(v => String(v ?? '').trim() === text);
}

export function rowIsEmpty(row: ExcelJS.Row) {
  const vs = row.values || [];
  return vs.every(v => v === null || v === undefined || String(v).trim() === '');
}

export function isTxHeaderRow(row: ExcelJS.Row) {
  const vals = (row.values || []).map(v => String(v ?? '').trim());
  const required = ['Belge Türü', 'Tarih', 'Evrak No', 'Açıklama', 'Vade Tarihi', 'Matrah', 'İskonto', 'Net Matrah', 'KDV', 'Borç Tutar', 'Alacak Tutar'];
  return required.every(r => vals.includes(r));
}

export function buildTxHeaderMap(row: ExcelJS.Row, map: Record<string, number>) {
  row.eachCell((cell, col) => {
    const key = String(cell.value ?? '').trim();
    if (key) map[key] = col;
  });
}

export function isTotalsRow(row: ExcelJS.Row, map: Record<string, number>) {
  const docType = getText(row, map['Belge Türü']);
  const tarih = getText(row, map['Tarih']);
  const matrah = getText(row, map['Matrah']);
  const borc = getText(row, map['Borç Tutar']);
  const alacak = getText(row, map['Alacak Tutar']);
  const numericPresent = [matrah, borc, alacak].some(isTL);
  return !docType && !tarih && numericPresent;
}

export function readCustomerHeader(ws: ExcelJS.Worksheet, startRow: number) {
  const r1 = ws.getRow(startRow);
  const r2 = ws.getRow(startRow + 1);
  const r3 = ws.getRow(startRow + 2);
  const rAddr = ws.getRow(startRow + 4);

  const header = {
    code: getValueRightOf(r1, 'Cari Kodu'),
    name: getValueRightOf(r2, 'Cari Adı'),
    phone: getValueRightOf(r1, 'Telefon'),
    address: getValueRightOf(rAddr, 'Adres'),
    accountType: getValueRightOf(r3, 'Cari Hesap Türü'),
    tag1: getValueRightOf(r3, 'Özel Kod(1)'),
    tag2: getValueRightOf(r3, 'Özel Kod(2)'),
    reportedTotalDebit: parseTL(getValueRightOf(r1, 'Borç')),
    reportedTotalCredit: parseTL(getValueRightOf(r2, 'Alacak')),
    reportedDebtBalance: parseTL(getValueRightOf(r1, 'Borç Bakiye')),
    reportedCreditBalance: parseTL(getValueRightOf(r2, 'Alacak Bakiye'))
  };

  let nextRow = startRow + 1;
  while (nextRow <= ws.rowCount) {
    if (isTxHeaderRow(ws.getRow(nextRow))) break;
    nextRow++;
  }
  return { header, nextRow };
}

export function parseTxRow(row: ExcelJS.Row, map: Record<string, number>) {
  const t = (k: string) => getText(row, map[k]);
  const n = (k: string) => parseTL(t(k));
  const dateOrNull = (s?: string) => (s ? parseDate(s) : null);

  return {
    docType: t('Belge Türü') || undefined,
    txnDate: parseDate(t('Tarih')),
    voucherNo: t('Evrak No') || undefined,
    description: t('Açıklama') || undefined,
    dueDate: dateOrNull(t('Vade Tarihi')),
    amountBase: n('Matrah'),
    discount: n('İskonto'),
    amountNet: n('Net Matrah'),
    vat: n('KDV'),
    debit: n('Borç Tutar') || 0,
    credit: n('Alacak Tutar') || 0
  };
}

function getText(row: ExcelJS.Row, col?: number) {
  if (!col) return '';
  return String(row.getCell(col).text || '').trim();
}
function isTL(s?: string) {
  if (!s) return false;
  const norm = s.replace(/\./g, '').replace(',', '.');
  return !!norm.match(/^-?\d+(\.\d+)?$/);
}
function getValueRightOf(row: ExcelJS.Row, label: string) {
  const cells = row.values as any[];
  for (let c = 1; c < cells.length; c++) {
    if (String(cells[c] ?? '').trim() === label) {
      return String(cells[c + 1] ?? '').trim();
    }
  }
  return '';
}
