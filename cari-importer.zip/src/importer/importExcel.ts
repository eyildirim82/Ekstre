import ExcelJS from 'exceljs';
import { PrismaClient } from '@prisma/client';
import { hash, hashJson } from '../utils/hash';
import { formatDate } from '../utils/date';
import {
  readCustomerHeader,
  buildTxHeaderMap,
  isTxHeaderRow,
  isTotalsRow,
  rowContains,
  rowIsEmpty,
  parseTxRow
} from './parser';

const prisma = new PrismaClient();

export async function importExcel(fileId: number, filePath: string) {
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.readFile(filePath);
  const ws = wb.worksheets[0];

  let i = 2;
  let state: 'SEEK_CUSTOMER'|'SEEK_TX_HEADER'|'READ_TX_ROWS' = 'SEEK_CUSTOMER';
  let currentCustomer: { id: number; code: string } | null = null;

  let inserted = 0, updated = 0, skipped = 0, total = 0;

  const balances: Array<{
    customerId: number,
    reported: {
      totalDebit: number, totalCredit: number, debtBalance: number, creditBalance: number
    }
  }> = [];

  const txHeaderMap: Record<string, number> = {};

  await prisma.$transaction(async (db) => {
    while (i <= ws.rowCount) {
      const row = ws.getRow(i);

      if (state === 'SEEK_CUSTOMER') {
        if (rowContains(row, 'Cari Kodu')) {
          const { header, nextRow } = readCustomerHeader(ws, i);
          i = nextRow;
          const cust = await db.customer.upsert({
            where: { code: header.code },
            create: {
              code: header.code, name: header.name, phone: header.phone,
              address: header.address, accountType: header.accountType,
              tag1: header.tag1, tag2: header.tag2
            },
            update: {
              name: header.name, phone: header.phone,
              address: header.address, accountType: header.accountType,
              tag1: header.tag1, tag2: header.tag2
            }
          });
          currentCustomer = { id: cust.id, code: cust.code };

          balances.push({
            customerId: cust.id,
            reported: {
              totalDebit: header.reportedTotalDebit ?? 0,
              totalCredit: header.reportedTotalCredit ?? 0,
              debtBalance: header.reportedDebtBalance ?? 0,
              creditBalance: header.reportedCreditBalance ?? 0
            }
          });

          state = 'SEEK_TX_HEADER';
          continue;
        }
        i++;
      }

      else if (state === 'SEEK_TX_HEADER') {
        if (isTxHeaderRow(row)) {
          buildTxHeaderMap(row, txHeaderMap);
          i++;
          state = 'READ_TX_ROWS';
          continue;
        }
        i++;
      }

      else if (state === 'READ_TX_ROWS') {
        if (rowContains(row, 'Cari Kodu')) {
          state = 'SEEK_CUSTOMER';
          continue;
        }
        if (isTotalsRow(row, txHeaderMap)) { i++; continue; }
        if (rowIsEmpty(row)) { i++; continue; }

        if (!currentCustomer) throw new Error('Customer context lost');

        const txr = parseTxRow(row, txHeaderMap);
        total++;

        const naturalKey = makeNaturalKey(currentCustomer.code, txr);
        const rowHash = hashJson({ ...txr, customer: currentCustomer.code });

        const existing = await db.transaction.findUnique({ where: { naturalKey } });
        if (!existing) {
          await db.transaction.create({
            data: {
              ...mapTxToDb(txr),
              naturalKey, rowHash,
              lastFileId: fileId,
              customer: { connect: { id: currentCustomer.id } },
              sources: { create: { fileId } }
            }
          });
          inserted++;
        } else {
          if (existing.rowHash !== rowHash) {
            await db.transaction.update({
              where: { id: existing.id },
              data: { ...mapTxToDb(txr), rowHash, lastFileId: fileId }
            });
            await db.transactionAudit.create({
              data: { oldTxnId: existing.id, newTxnId: existing.id, fileId, reason: 'OVERWRITE' }
            });
            updated++;
          } else {
            skipped++;
          }
        }

        i++;
      }
    }

    // balance snapshots
    for (const b of balances) {
      const sums = await db.transaction.aggregate({
        _sum: { debit: true, credit: true },
        where: { customerId: b.customerId }
      });
      const d = Number(sums._sum.debit ?? 0);
      const c = Number(sums._sum.credit ?? 0);
      const calcDebt = Math.max(d - c, 0);
      const calcCredit = Math.max(c - d, 0);

      await db.customerBalanceSnapshot.upsert({
        where: { customerId_fileId: { customerId: b.customerId, fileId } },
        create: {
          customerId: b.customerId, fileId,
          reportedTotalDebit: b.reported.totalDebit,
          reportedTotalCredit: b.reported.totalCredit,
          reportedDebtBalance: b.reported.debtBalance,
          reportedCreditBalance: b.reported.creditBalance,
          calcTotalDebit: d,
          calcTotalCredit: c,
          calcDebtBalance: calcDebt,
          calcCreditBalance: calcCredit,
          diffTotalDebit: d - b.reported.totalDebit,
          diffTotalCredit: c - b.reported.totalCredit,
          diffDebtBalance: calcDebt - b.reported.debtBalance,
          diffCreditBalance: calcCredit - b.reported.creditBalance
        },
        update: {}
      });
    }

    await db.stagingFile.update({
      where: { id: fileId },
      data: {
        status: 'PROCESSED',
        rowCount: total,
        insertedCount: inserted,
        updatedCount: updated,
        skippedCount: skipped
      }
    });
  });

  return { total, inserted, updated, skipped };
}

function makeNaturalKey(code: string, tx: any) {
  return hash(`${code}|${tx.docType||''}|${formatDate(tx.txnDate)}|${tx.voucherNo||''}`);
}

function mapTxToDb(tx: any) {
  return {
    docType: tx.docType,
    txnDate: tx.txnDate,
    voucherNo: tx.voucherNo || null,
    description: tx.description || null,
    dueDate: tx.dueDate ?? null,
    amountBase: tx.amountBase ?? null,
    discount: tx.discount ?? null,
    amountNet: tx.amountNet ?? null,
    vat: tx.vat ?? null,
    debit: tx.debit,
    credit: tx.credit,
    currency: 'TRY'
  };
}
