import 'dotenv/config';
import express from 'express';
import { PrismaClient } from '@prisma/client';
import importsRouter from './routes/imports';

const prisma = new PrismaClient();
const app = express();

app.get('/health', (_req, res) => res.send('ok'));

app.use('/imports', importsRouter);

app.get('/customers/:code/balances', async (req, res) => {
  const code = req.params.code;
  const customer = await prisma.customer.findUnique({ where: { code } });
  if (!customer) return res.status(404).send();

  const snapshots = await prisma.customerBalanceSnapshot.findMany({
    where: { customerId: customer.id },
    include: { file: true }
  });

  res.json({ customer: { code: customer.code, name: customer.name }, snapshots });
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`http://localhost:${port}`));
